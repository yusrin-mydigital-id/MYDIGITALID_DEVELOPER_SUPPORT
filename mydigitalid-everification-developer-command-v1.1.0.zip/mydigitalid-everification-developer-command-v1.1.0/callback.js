(function () {
  'use strict';

  // --- Crypto helpers (Web Crypto API) ---

  async function sha256Hex(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  async function computeCallbackEnc(hash, refId, score, status, clientSecret) {
    const str = `hash${hash}ref_id${refId}score${score}status${status}${clientSecret}`;
    return sha256Hex(str);
  }

  async function computeEncDebug(hash, refId, score, status, clientSecret) {
    const template = 'hash{HASH_VAL}ref_id{REF_ID_VAL}score{SCORE_VAL}status{STATUS_VAL}{SECRET_VAL}';
    const stringToHash = `hash${hash}ref_id${refId}score${score}status${status}${clientSecret}`;
    const encHash = await sha256Hex(stringToHash);
    return { template, stringToHash, encHash };
  }

  function getTimestamp(formTimestamp) {
    const trimmed = (formTimestamp || '').trim();
    if (trimmed) return trimmed;
    return new Date().toISOString();
  }

  async function buildCallbackBody(formData) {
    const hash = formData.hash.trim();
    const refId = formData.refId.trim();
    const status = formData.status.trim();
    const clientSecret = formData.clientSecret.trim();
    const isSuccess = status === '2000';
    const score = isSuccess ? String(formData.score) : '0';

    const enc = await computeCallbackEnc(hash, refId, score, status, clientSecret);

    const body = {
      ref_id: refId,
      hash,
      score: parseFloat(score),
      status: parseInt(status, 10),
      timestamp: getTimestamp(formData.timestamp),
      enc,
    };

    if (formData.clientRefId.trim()) {
      body.client_ref_id = formData.clientRefId.trim();
    }

    return body;
  }

  // --- Form & validation ---

  function getFormData() {
    const callbackUrl = document.getElementById('callback-url').value.trim();
    const clientSecret = document.getElementById('client-secret').value.trim();
    const refId = document.getElementById('ref-id').value.trim();
    const clientRefId = document.getElementById('client-ref-id').value.trim();
    const hash = document.getElementById('hash').value.trim();
    const score = document.getElementById('score').value.trim();
    const status = document.getElementById('status').value.trim();
    const timestamp = document.getElementById('timestamp').value.trim();

    return {
      callbackUrl,
      clientSecret,
      refId,
      clientRefId,
      hash,
      score,
      status,
      timestamp,
    };
  }

  function validateFormData(data) {
    const required = [
      ['callbackUrl', 'Callback URL'],
      ['clientSecret', 'Client Secret'],
      ['refId', 'ref_id'],
      ['hash', 'hash'],
      ['score', 'score'],
      ['status', 'status'],
    ];
    for (const [key, label] of required) {
      if (!data[key]) {
        return `${label} is required`;
      }
    }
    try {
      new URL(data.callbackUrl);
    } catch {
      return 'Callback URL must be a valid URL';
    }
    const scoreNum = parseFloat(data.score);
    const isSuccess = data.status === '2000';
    if (isSuccess) {
      if (isNaN(scoreNum) || scoreNum < 80 || scoreNum > 100) {
        return 'score must be between 80 and 100 when status is 2000 (Success)';
      }
    } else {
      if (isNaN(scoreNum) || scoreNum !== 0) {
        return 'score must be 0 when status is not 2000';
      }
    }
    return null;
  }

  // --- Output ---

  const outputEl = document.getElementById('output');
  const outputContent = document.getElementById('output-content');
  const btnCopy = document.getElementById('btn-copy');

  const encDebugSection = document.getElementById('enc-debug-section');

  let lastCopyableText = '';

  function setEncDebugValue(id, text) {
    const el = document.querySelector(`#${id} code`);
    if (el) el.textContent = text || '';
  }

  function populateEncDebug(debug) {
    if (!debug) {
      encDebugSection.style.display = 'none';
      return;
    }
    encDebugSection.style.display = 'block';
    setEncDebugValue('enc-debug-template', debug.template);
    setEncDebugValue('enc-debug-string', debug.stringToHash);
    setEncDebugValue('enc-debug-hash', debug.encHash);
  }

  function getEncDebugCopyText(targetId) {
    const el = document.querySelector(`#${targetId} code`);
    return el ? el.textContent : '';
  }

  function setCopyable(text) {
    lastCopyableText = text || '';
    btnCopy.style.display = lastCopyableText ? 'inline-block' : 'none';
  }

  function setOutput(text, type) {
    outputContent.textContent = text;
    outputEl.classList.remove('error', 'success');
    if (type) outputEl.classList.add(type);
  }

  function setOutputError(message) {
    setOutput(message, 'error');
    setCopyable(message);
  }

  // --- Generate curl ---

  function escapeForShell(str) {
    return "'" + str.replace(/'/g, "'\\''") + "'";
  }

  async function generateCurl() {
    const data = getFormData();
    const err = validateFormData(data);
    if (err) {
      setOutputError(err);
      populateEncDebug(null);
      return;
    }

    try {
      const debug = await computeEncDebug(
        data.hash,
        data.refId,
        data.score,
        data.status,
        data.clientSecret
      );
      populateEncDebug(debug);
      const body = await buildCallbackBody(data);
      const url = data.callbackUrl.replace(/\/$/, '');
      const bodyJson = JSON.stringify(body);

      const lines = [
        `curl -X POST ${escapeForShell(url)} \\`,
        `  -H 'Content-Type: application/json' \\`,
        `  -d ${escapeForShell(bodyJson)}`,
      ];
      const curl = lines.join('\n');
      setOutput(curl);
      setCopyable(curl);
    } catch (e) {
      setOutputError('Error: ' + (e.message || String(e)));
      populateEncDebug(null);
    }
  }

  // --- Perform fetch ---

  async function performFetch() {
    const data = getFormData();
    const err = validateFormData(data);
    if (err) {
      setOutputError(err);
      populateEncDebug(null);
      return;
    }

    const btn = document.getElementById('btn-perform-fetch');
    btn.disabled = true;
    setOutput('Sending request...');
    setCopyable('');

    try {
      const debug = await computeEncDebug(
        data.hash,
        data.refId,
        data.score,
        data.status,
        data.clientSecret
      );
      populateEncDebug(debug);
      const body = await buildCallbackBody(data);
      const url = data.callbackUrl.replace(/\/$/, '');

      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      const text = await res.text();
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }

      const output = {
        status: res.status,
        statusText: res.statusText,
        body: parsed,
      };

      const formatted = JSON.stringify(output, null, 2);
      setOutput(formatted, res.ok ? 'success' : 'error');
      setCopyable(formatted);
    } catch (e) {
      setOutputError('Network error: ' + (e.message || String(e)));
      setCopyable('');
      populateEncDebug(null);
    } finally {
      btn.disabled = false;
    }
  }

  // --- Copy ---

  function copyToClipboard() {
    if (!lastCopyableText) return;
    navigator.clipboard.writeText(lastCopyableText).then(
      () => {
        const orig = btnCopy.textContent;
        btnCopy.textContent = 'Copied!';
        setTimeout(() => { btnCopy.textContent = orig; }, 1500);
      },
      () => setOutputError('Copy failed')
    );
  }

  // --- Score/status sync ---

  function syncScoreField() {
    const statusEl = document.getElementById('status');
    const scoreEl = document.getElementById('score');
    const isSuccess = statusEl.value === '2000';
    if (isSuccess) {
      scoreEl.disabled = false;
      scoreEl.min = '80';
      scoreEl.max = '100';
      const val = parseFloat(scoreEl.value);
      if (isNaN(val) || val < 80 || val > 100) {
        scoreEl.value = '90';
      }
    } else {
      scoreEl.disabled = true;
      scoreEl.value = '0';
    }
  }

  // --- Event listeners ---

  document.getElementById('btn-generate-ref-id').addEventListener('click', function () {
    document.getElementById('ref-id').value = crypto.randomUUID();
  });

  document.getElementById('btn-generate-hash').addEventListener('click', function () {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    const hex = Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
    document.getElementById('hash').value = hex;
  });

  document.getElementById('status').addEventListener('change', syncScoreField);

  document.getElementById('btn-generate-curl').addEventListener('click', generateCurl);
  document.getElementById('btn-perform-fetch').addEventListener('click', performFetch);
  btnCopy.addEventListener('click', copyToClipboard);

  document.querySelectorAll('.btn-copy-value').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const targetId = this.getAttribute('data-target');
      const text = getEncDebugCopyText(targetId);
      if (!text) return;
      navigator.clipboard.writeText(text).then(
        function () {
          const orig = btn.textContent;
          btn.textContent = 'Copied!';
          setTimeout(function () { btn.textContent = orig; }, 1500);
        },
        function () { setOutputError('Copy failed'); }
      );
    });
  });

  document.getElementById('callback-form').addEventListener('submit', (e) => {
    e.preventDefault();
  });

  syncScoreField();
})();
