# Run
1) Double click the index.html and open it in your local browser
2) Fill in the x-api-key, x-client-id and client secret
3) Fill in the name & ic no.
4) Optional - Fill in client ref id or press the generate new ref id
5) Generate curl and run in terminal OR press the perform fetch

Expected result:
The user with the name & ic no. will get a notification for eVerification.