(function () {
  'use strict';

  const ENDPOINT = '/api/v1/notify/everification';

  // --- Crypto helpers (Web Crypto API) ---

  async function sha256Hex(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(str);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  async function deriveAesKey(clientSecret) {
    const encoder = new TextEncoder();
    const data = encoder.encode(clientSecret);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return crypto.subtle.importKey(
      'raw',
      hashBuffer,
      { name: 'AES-GCM' },
      false,
      ['encrypt']
    );
  }

  async function aesGcmEncrypt(plaintext, clientSecret) {
    const key = await deriveAesKey(clientSecret);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const encoded = encoder.encode(plaintext);

    const ciphertextWithTag = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv,
        tagLength: 128,
      },
      key,
      encoded
    );

    const tagLen = 16;
    const ctArr = new Uint8Array(ciphertextWithTag);
    const ciphertext = ctArr.slice(0, ctArr.length - tagLen);
    const tag = ctArr.slice(ctArr.length - tagLen);

    const combined = new Uint8Array(iv.length + tag.length + ciphertext.length);
    combined.set(iv, 0);
    combined.set(tag, iv.length);
    combined.set(ciphertext, iv.length + tag.length);

    return Array.from(combined)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  async function computeEnc(name, icNo, clientSecret) {
    const str = `name${name}ic_no${icNo}${clientSecret}`;
    return sha256Hex(str);
  }

  async function computeEncDebug(name, icNo, clientSecret) {
    const template = 'name{NAME_VAL}ic_no{ICNO_VAL}{SECRET_VAL}';
    const stringToHash = `name${name}ic_no${icNo}${clientSecret}`;
    const encHash = await sha256Hex(stringToHash);
    return { template, stringToHash, encHash };
  }

  async function buildRequestBody(formData) {
    const name = formData.name.trim();
    const icNo = formData.icNo.trim();
    const clientSecret = formData.clientSecret.trim();
    const isEncrypted = formData.isEncrypted;

    const enc = await computeEnc(name, icNo, clientSecret);

    let body = {
      enc,
      is_encrypted: isEncrypted,
    };

    if (isEncrypted) {
      body.name = await aesGcmEncrypt(name, clientSecret);
      body.ic_no = await aesGcmEncrypt(icNo, clientSecret);
    } else {
      body.name = name;
      body.ic_no = icNo;
    }

    if (formData.clientRefId.trim()) {
      body.client_ref_id = formData.clientRefId.trim();
    }
    if (formData.svcType.trim()) {
      body.svc_type = formData.svcType.trim();
    }

    return body;
  }

  // --- Form & validation ---

  function getFormData() {
    const baseUrl = document.getElementById('base-url').value.trim();
    const apiKey = document.getElementById('api-key').value.trim();
    const clientId = document.getElementById('client-id').value.trim();
    const clientSecret = document.getElementById('client-secret').value.trim();
    const name = document.getElementById('name').value.trim();
    const icNo = document.getElementById('ic-no').value.trim();
    const clientRefId = document.getElementById('client-ref-id').value.trim();
    const svcType = document.getElementById('svc-type').value.trim();
    const isEncrypted = document.getElementById('is-encrypted').checked;

    return {
      baseUrl,
      apiKey,
      clientId,
      clientSecret,
      name,
      icNo,
      clientRefId,
      svcType,
      isEncrypted,
    };
  }

  function validateFormData(data) {
    const required = [
      ['baseUrl', 'Base URL'],
      ['apiKey', 'x-api-key'],
      ['clientId', 'x-client-id'],
      ['clientSecret', 'Client Secret'],
      ['name', 'Name'],
      ['icNo', 'IC No.'],
    ];
    for (const [key, label] of required) {
      if (!data[key]) {
        return `${label} is required`;
      }
    }
    try {
      new URL(data.baseUrl);
    } catch {
      return 'Base URL must be a valid URL';
    }
    return null;
  }

  // --- Output ---

  const outputEl = document.getElementById('output');
  const outputContent = document.getElementById('output-content');
  const btnCopy = document.getElementById('btn-copy');

  const encDebugSection = document.getElementById('enc-debug-section');

  let lastCopyableText = '';

  function setEncDebugValue(id, text) {
    const el = document.querySelector(`#${id} code`);
    if (el) el.textContent = text || '';
  }

  function populateEncDebug(debug) {
    if (!debug) {
      encDebugSection.style.display = 'none';
      return;
    }
    encDebugSection.style.display = 'block';
    setEncDebugValue('enc-debug-template', debug.template);
    setEncDebugValue('enc-debug-string', debug.stringToHash);
    setEncDebugValue('enc-debug-hash', debug.encHash);
  }

  function getEncDebugCopyText(targetId) {
    const el = document.querySelector(`#${targetId} code`);
    return el ? el.textContent : '';
  }

  function setCopyable(text) {
    lastCopyableText = text || '';
    btnCopy.style.display = lastCopyableText ? 'inline-block' : 'none';
  }

  function setOutput(text, type) {
    outputContent.textContent = text;
    outputEl.classList.remove('error', 'success');
    if (type) outputEl.classList.add(type);
  }

  function setOutputError(message) {
    setOutput(message, 'error');
    setCopyable(message);
  }

  // --- Generate curl ---

  function escapeForShell(str) {
    return "'" + str.replace(/'/g, "'\\''") + "'";
  }

  async function generateCurl() {
    const data = getFormData();
    const err = validateFormData(data);
    if (err) {
      setOutputError(err);
      populateEncDebug(null);
      return;
    }

    try {
      const debug = await computeEncDebug(data.name, data.icNo, data.clientSecret);
      populateEncDebug(debug);
      const body = await buildRequestBody(data);
      const url = data.baseUrl.replace(/\/$/, '') + ENDPOINT;
      const bodyJson = JSON.stringify(body);

      const lines = [
        `curl -X POST ${escapeForShell(url)} \\`,
        `  -H 'Content-Type: application/json' \\`,
        `  -H 'x-api-key: ${data.apiKey}' \\`,
        `  -H 'x-client-id: ${data.clientId}' \\`,
        `  -d ${escapeForShell(bodyJson)}`,
      ];
      const curl = lines.join('\n');
      setOutput(curl);
      setCopyable(curl);
    } catch (e) {
      setOutputError('Error: ' + (e.message || String(e)));
      populateEncDebug(null);
    }
  }

  // --- Perform fetch ---

  async function performFetch() {
    const data = getFormData();
    const err = validateFormData(data);
    if (err) {
      setOutputError(err);
      populateEncDebug(null);
      return;
    }

    const btn = document.getElementById('btn-perform-fetch');
    btn.disabled = true;
    setOutput('Sending request...');
    setCopyable('');

    try {
      const debug = await computeEncDebug(data.name, data.icNo, data.clientSecret);
      populateEncDebug(debug);
      const body = await buildRequestBody(data);
      const url = data.baseUrl.replace(/\/$/, '') + ENDPOINT;

      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': data.apiKey,
          'x-client-id': data.clientId,
        },
        body: JSON.stringify(body),
      });

      const text = await res.text();
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }

      const output = {
        status: res.status,
        statusText: res.statusText,
        headers: {
          'X-RateLimit-Limit': res.headers.get('X-RateLimit-Limit'),
          'X-RateLimit-Remaining': res.headers.get('X-RateLimit-Remaining'),
          'X-RateLimit-Window': res.headers.get('X-RateLimit-Window'),
        },
        body: parsed,
      };

      const formatted = JSON.stringify(output, null, 2);
      setOutput(formatted, res.ok ? 'success' : 'error');
      setCopyable(formatted);
    } catch (e) {
      setOutputError('Network error: ' + (e.message || String(e)));
      setCopyable('');
      populateEncDebug(null);
    } finally {
      btn.disabled = false;
    }
  }

  // --- Copy ---

  function copyToClipboard() {
    if (!lastCopyableText) return;
    navigator.clipboard.writeText(lastCopyableText).then(
      () => {
        const orig = btnCopy.textContent;
        btnCopy.textContent = 'Copied!';
        setTimeout(() => { btnCopy.textContent = orig; }, 1500);
      },
      () => setOutputError('Copy failed')
    );
  }

  // --- Event listeners ---

  document.getElementById('name').addEventListener('input', function () {
    this.value = this.value.toUpperCase();
  });

  document.getElementById('ic-no').addEventListener('input', function () {
    this.value = this.value.replace(/[^0-9]/g, '');
  });

  document.getElementById('btn-generate-ref-id').addEventListener('click', function () {
    document.getElementById('client-ref-id').value = 'client_ref_id_' + crypto.randomUUID();
  });

  document.getElementById('btn-generate-curl').addEventListener('click', generateCurl);
  document.getElementById('btn-perform-fetch').addEventListener('click', performFetch);
  btnCopy.addEventListener('click', copyToClipboard);

  document.querySelectorAll('.btn-copy-value').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const targetId = this.getAttribute('data-target');
      const text = getEncDebugCopyText(targetId);
      if (!text) return;
      navigator.clipboard.writeText(text).then(
        function () {
          const orig = btn.textContent;
          btn.textContent = 'Copied!';
          setTimeout(function () { btn.textContent = orig; }, 1500);
        },
        function () { setOutputError('Copy failed'); }
      );
    });
  });

  document.getElementById('everification-form').addEventListener('submit', (e) => {
    e.preventDefault();
  });
})();
