<?php
//Token Settings

include "config.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyDigital ID | Expert e-Verify Tool</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen py-10 px-4">

    <div class="max-w-2xl mx-auto bg-white shadow-lg rounded-xl overflow-hidden">
        <div class="bg-blue-800 p-6">
            <h1 class="text-white text-2xl font-bold">MyDigital ID e-Verification</h1>
            <p class="text-blue-200 text-sm">Face Scoring from Identity Document (Local Test Tool)</p>
        </div>

        <form method="POST" enctype="multipart/form-data" class="p-8 space-y-6">
            
            <!-- API Configuration -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 border-b pb-6">
                <div class="md:col-span-2"><h2 class="font-semibold text-gray-700">1. API Settings</h2></div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase">Host URL</label>
                    <input type="text" name="host" value="<?php echo $HOST;?>" required
                        class="w-full mt-1 p-2 border rounded bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase">Bearer Token</label>
                    <input type="text" name="apiToken" value="<?php echo $TOKEN; ?>" required
                        class="w-full mt-1 p-2 border rounded bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none">
                </div>
            </div>

            <!-- Identity Data -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="md:col-span-2"><h2 class="font-semibold text-gray-700">2. Identity Details</h2></div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase">Full Name</label>
                    <input type="text" name="name" value="" required
                        class="w-full mt-1 p-2 border rounded focus:ring-2 focus:ring-blue-500 outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 uppercase">IC Number</label>
                    <input type="text" name="icNumber" value="" required
                        class="w-full mt-1 p-2 border rounded focus:ring-2 focus:ring-blue-500 outline-none">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-xs font-bold text-gray-500 uppercase">Upload MyKad Front (Cropped)</label>
                    <input type="file" name="imageFile" accept="image/*" required
                        class="w-full mt-1 text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                </div>
            </div>

            <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition shadow-md">
                Run Verification Scan
            </button>
        </form>

        <!-- Response Section -->
        <div class="p-8 border-t bg-gray-50">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $host = rtrim($_POST['host'], '/');
                $apiToken = $_POST['apiToken'];
                $apiUrl = $host . "/ekyc/face-verify/face-scoring-from-id";

                // Handle the File Upload
                if (isset($_FILES['imageFile']) && $_FILES['imageFile']['error'] === UPLOAD_ERR_OK) {
                    $tmpPath = $_FILES['imageFile']['tmp_name'];
                    $mimeType = $_FILES['imageFile']['type'];
                    $fileName = $_FILES['imageFile']['name'];

                    // Prepare Multipart Data
                    $postFields = [
                        'name'      => $_POST['name'],
                        'icNumber'  => $_POST['icNumber'],
                        'imageFile' => new CURLFile($tmpPath, $mimeType, $fileName)
                    ];

                    $ch = curl_init();
                    curl_setopt_array($ch, [
                        CURLOPT_URL => $apiUrl,
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => $postFields,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_HTTPHEADER => [
                            "Authorization: Bearer $apiToken"
                        ],
                    ]);

                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $error = curl_error($ch);
                    curl_close($ch);

                    if ($error) {
                        echo "<div class='p-4 bg-red-100 text-red-700 rounded'>Connection Error: $error</div>";
                    } else {
                        $result = json_decode($response, true);
                        
                        if (isset($result['status']) && $result['status'] === 'success') {
                            echo "<div class='p-4 bg-green-100 border border-green-300 rounded'>";
                            echo "<h3 class='font-bold text-green-800'>Success!</h3>";
                            echo "<p class='text-sm'>Face Match: <span class='font-mono'>" . ($result['data']['faceMatch'] ? 'YES' : 'NO') . "</span></p>";
                            echo "<p class='text-sm'>Confidence Score: <span class='font-mono'>" . $result['data']['faceScore'] . "</span></p>";
                            echo "</div>";
                        } else {
                            echo "<div class='p-4 bg-orange-100 border border-orange-300 rounded'>";
                            echo "<h3 class='font-bold text-orange-800'>API Refused Verification</h3>";
                            echo "<p class='text-sm'>Message: " . ($result['message'] ?? 'Check input data') . "</p>";
                            echo "<p class='text-sm'>Status Code: " . ($result['code'] ?? $httpCode) . "</p>";
                            echo "</div>";
                        }
                    }
                } else {
                    echo "<div class='p-4 bg-yellow-100 text-yellow-700 rounded'>Please upload a valid image file.</div>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>