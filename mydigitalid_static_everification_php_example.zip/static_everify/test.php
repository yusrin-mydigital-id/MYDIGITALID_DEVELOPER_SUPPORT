<?php



/**
 * MyDigital ID / eKYC Face Scoring Service
 * Executes a verification request using local file paths.
 */

// 1. Configuration Constants

include "config.php";

// 2. Input Data (Replace these with your actual database variables)
$userData = [
    'name'      => 'AMRU BIN AMRUDDIN',
    'icNumber'  => '760714145372',
    'imagePath' => __DIR__ . '\face.jpg' // Full path to the image on your server
];

// 3. Execution Logic
try {
    $result = verifyFaceFromID($HOST, $TOKEN, $userData);
    
    // Output Result as JSON (For logging or API response)
    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

/**
 * Core Function to call the eKYC API
 */
function verifyFaceFromID($host, $token, $data) {
    $apiUrl = rtrim($host, '/') . "/ekyc/face-verify/face-scoring-from-id";

    // Validate if file exists before calling API
    if (!file_exists($data['imagePath'])) {
        throw new Exception("Image file not found at: " . $data['imagePath']);
    }
	
	$fileInfo = getimagesize($data['imagePath']);
    if ($fileInfo['mime'] !== 'image/jpeg') {
        throw new Exception("Unsupported Format: The file is a " . $fileInfo['mime'] . ". Please convert to JPEG.");
    }

    // Prepare Multipart Data using CURLFile
    $postFields = [
        'name'      => $data['name'],
        'icNumber'  => $data['icNumber'],
        'imageFile' => new CURLFile($data['imagePath'], 'image/jpeg', 'verified_photo.jpg')
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $apiUrl,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $postFields,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            "Authorization: Bearer $token"
        ],
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($error) {
        throw new Exception("CURL Error: " . $error);
    }

    return json_decode($response, true);
}



?>