<?php

$HOST  = "https://wiseconsole-saas-dev.wiseai.tech/saastest";
$TOKEN = ""; //Please put Static E-verify here!


?>