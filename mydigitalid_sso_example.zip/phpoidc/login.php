<?php
require 'config.php';

$oidc = getOIDCClient();
$oidc->authenticate(); // redirects to Google

?>
