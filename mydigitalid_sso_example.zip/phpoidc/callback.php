<?php
require 'config.php';

$oidc = getOIDCClient();
$oidc->authenticate();


$_SESSION['user'] = [
    'nama' => $oidc->requestUserInfo('nama'),
    'nric'  => $oidc->requestUserInfo('nric'),
    'token_id' => $oidc->getIdToken(),
];

header('Location: index.php');
exit;
?>
