<?php
session_start();

require 'vendor/autoload.php';

use Jumbojett\OpenIDConnectClient;


$realm = "diddev"; //PUT YOUR REALM HERE!
$domain = "localhost";
$port = "8080";
$clientid = "phpoidc"; //PUT YOUR CLIENT ID HERE!
$secretkey = "HOOCQlSVBkg0mcezo869KyPrnWfwIxcl";  //PUT YOUR SECRET KEY HERE!



$redirect_url_after_logout="http://".$domain.":".$port."/phpoidc/logout.php"; //PUT URL REDIRECTION AFTER LOGOUT
$redirect_url_encode_after_logout= urlencode($redirect_url_after_logout);

function getOIDCClient() {
	
	global $realm;
	global $port;
	global $clientid;
	global $secretkey;
	global $domain;
	
    $oidc = new OpenIDConnectClient(
        'https://sso.digital-id.my/realms/'.$realm,
        $clientid,
	$secretkey
    );
   

    $oidc->providerConfigParam(['token_endpoint'=>'https://sso.digital-id.my/realms/'.$realm.'/protocol/openid-connect/token','end_session_endpoint'=>'https://sso.digital-id.my/oidc/session/end']);
    $oidc->setRedirectURL('http://'.$domain.':'.$port.'/phpoidc/callback.php'); //PUT YOUR CALLBACK URL HERE!
    $oidc->addScope(['openid']);

    return $oidc;
}




?>
