<?php
require 'config.php';

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$oidc = getOIDCClient();



if (!isset($_SESSION['user'])) {
    echo '<a href="login.php">Login with MyDigital ID</a>';
    exit;
}

$user = $_SESSION['user'];
?>
 <meta charset="UTF-8">
 <meta http-equiv="Cache-Control" content="no-cache">
<h1>Welcome, <?= htmlspecialchars($user['nama']) ?>!</h1>
<h1>NRIC: <?= htmlspecialchars($user['nric']) ?></h1>
<p>Token ID Hint:<br> <?= htmlspecialchars($user['token_id']) ?></p>
<br><hr>

<a href="https://sso.digital-id.my/realms/<?php echo $realm; ?>/protocol/openid-connect/logout?client_id=<?php echo $clientid; ?>&post_logout_redirect_uri=<?php echo $redirect_url_encode_after_logout; ?>">Logout without ID Token Hint</a>
<br><br>
<a href="https://sso.digital-id.my/realms/<?php echo $realm; ?>/protocol/openid-connect/logout?client_id=<?php echo $clientid; ?>&post_logout_redirect_uri=<?php echo $redirect_url_encode_after_logout; ?>&id_token_hint=<?php echo $user['token_id']; ?>">Logout with ID Token Hint</a>