<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Security-Policy: frame-ancestors 'self' https://digital-id.my;");




file_get_contents('https://sso.digital-id.my/oidc/session/end');

if (isset($_COOKIE)) {
    foreach ($_COOKIE as $key => $value) {
        setcookie($key, '', time() - 3600, '/'); // Expire the cookie
    }
}


session_destroy();
setcookie(session_name(), '', time() - 3600, '/');


?>

<meta http-equiv="Content-Security-Policy" content="frame-ancestors 'self' https://digital-id.my;">
 <meta charset="UTF-8">
    <meta http-equiv="Cache-Control" content="no-cache">
<script>
fetch("https://sso.digital-id.my/oidc/session/end")
  .then(response => console.log("Request sent successfully"))
  .catch(error => console.error("Error:", error));

var xhr = new XMLHttpRequest();
xhr.open("GET", "https://sso.digital-id.my/oidc/session/end", true);
xhr.send();

document.cookie.split(";").forEach((cookie) => {
    const name = cookie.split("=")[0].trim();
    document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
});
sessionStorage.clear();
localStorage.clear();


setTimeout(function() {window.location.href = "index.php";}, 3000); // Redirects after 3 seconds

</script>

<iframe scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height="0px" width="0px" src="https://sso.digital-id.my/oidc/session/end" ></iframe>
<iframe src="https://sso.digital-id.my/oidc/session/end" style="display:none;"></iframe>
<iframe src="https://sso.digital-id.my/oidc/session/end" style="border:1px #ffffff none;" name="myiFrame" scrolling="no" frameborder="0" marginheight="0px" marginwidth="0px" height="0px" width="0px" allowfullscreen></iframe>

<?php

echo "Logout Success...";
exit;

?>
